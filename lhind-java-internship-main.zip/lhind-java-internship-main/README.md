## LHIND java internship

#### [Exercise 1](https://github.com/BTabaku/lhind-java-internship/tree/main/src/main/java/com/internship/session1)

#### [Exercise 2](https://github.com/BTabaku/lhind-java-internship/tree/main/src/main/java/com/internship/session2)

#### [Exercise 3](https://github.com/BTabaku/lhind-java-internship/tree/main/src/main/java/com/internship/session3)

#### [Exercise 4 JDBC](https://github.com/BTabaku/lhind-java-internship/tree/main/src/main/java/com/internship/session4jdbc)